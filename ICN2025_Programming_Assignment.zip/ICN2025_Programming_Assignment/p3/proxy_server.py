# Set the server IP address and port
# TODO Start
HOST, PORT =
# TODO end

# Create a server socket, bind it to the specified IP and port, and start listening
# TODO Start
serverSocket =
# TODO end

while True:
    print('Ready to serve...')
    # Accept an incoming connection and get the client's address
    # TODO Start
    client_socket, client_address =
    # TODO end

    print('Received a connection from:', client_address)

    try:
        # Receive and parse the client's request
        # TODO Start
        request =
        # TODO end
        print(request)       

        # Extract the requested filename from the HTTP request
        if request == "":
            request = "/ /"
        filename = request.split()[1].partition("/")[2]
        print(filename)
        file_path = "/" + filename
        print(file_path)

        # Check if the requested file is available in the cache
        file_exist = "false"
        try:
            with open(file_path[1:], "r") as cache_file:
                output_data = cache_file.readlines()
            file_exist = "true"

            # ProxyServer finds a cache hit and generates a response message
            # Send the file data to the client
            # TODO Start
            # TODO End
            print('Read from cache')

        # If the file is not found in the cache, forward the request to the web server
        except FileNotFoundError:
            if file_exist == "false":
                # # Establish a connection to the web server
                # TODO Start
                # TODO End

                try:
                    print("Trying to connect to the web server")
                    # Connect the socket to the web server port
                    # TODO Start
                    # TODO End
                    print("Connected successfully")

                    # Send HTTP GET request to the web server
                    # TODO Start
                    # TODO End
                    print("Sent the request to the web server successfully")


                    # Receive response from the web server    
                    # If the response indicates a 404 error, return an error to the client without caching
                    # TODO Start
                    # TODO End                    

                    # If not, cache only valid files and send the valid response to the client socket
                    # TODO Start
                    # TODO End

                except:
                    # Handle errors related to connection issues or invalid requests
                    print("Illegal request")

                finally:
                    # Ensure the connection to the web server is closed properly
                    # TODO Start
                    # TODO End
    finally:
        # Close the client socket
        client_socket.close()